<?php return array (
  'app' => 
  array (
    'version' => 'v0.12.1',
    'name' => 'Admin Llorente Furniture',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://127.0.0.1:8000',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:sv8fPF5XGZNr4nkWdioHwkjZR8YXD95ECiSAndyTAKM=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\Filament\\AdminPanelProvider',
      26 => 'App\\Providers\\Filament\\BranchPanelProvider',
      27 => 'App\\Providers\\HorizonServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
      29 => 'App\\Providers\\HealthCheckServiceProvider',
      30 => 'App\\Providers\\ActivityLogPipeChangesProvider',
      31 => 'Domain\\Access\\Role\\RoleServiceProvider',
      32 => 'Domain\\Shop\\Order\\OrderServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'app-sentry' => 
  array (
    'organization_slug' => NULL,
    'project_slug' => NULL,
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'admin',
      'passwords' => 'admin',
    ),
    'guards' => 
    array (
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admin',
      ),
      'api' => 
      array (
        'driver' => 'session',
        'provider' => 'customer',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'admin' => 
      array (
        'driver' => 'eloquent',
        'model' => 'Domain\\Access\\Admin\\Models\\Admin',
      ),
      'customer' => 
      array (
        'driver' => 'eloquent',
        'model' => 'Domain\\Shop\\Customer\\Models\\Customer',
      ),
    ),
    'passwords' => 
    array (
      'admin' => 
      array (
        'provider' => 'admin',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'backup' => 
  array (
    'backup' => 
    array (
      'name' => 'Admin Llorente Furniture',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => 'C:\\laragon\\www\\qoqet\\storage\\app/public',
          ),
          'exclude' => 
          array (
            0 => 'C:\\laragon\\www\\qoqet\\vendor',
            1 => 'C:\\laragon\\www\\qoqet\\node_modules',
          ),
          'follow_links' => false,
          'ignore_unreadable_directories' => false,
          'relative_path' => NULL,
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'database_dump_compressor' => NULL,
      'database_dump_file_extension' => '',
      'destination' => 
      array (
        'filename_prefix' => '',
        'disks' => 
        array (
          0 => 'local-backup',
        ),
      ),
      'temporary_directory' => 'C:\\laragon\\www\\qoqet\\storage\\app/backup-temp',
      'password' => NULL,
      'encryption' => 'default',
    ),
    'notifications' => 
    array (
      'notifications' => 
      array (
        'Spatie\\Backup\\Notifications\\Notifications\\BackupHasFailedNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\UnhealthyBackupWasFoundNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupHasFailedNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\BackupWasSuccessfulNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\HealthyBackupWasFoundNotification' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupWasSuccessfulNotification' => 
        array (
          0 => 'mail',
        ),
      ),
      'notifiable' => 'Spatie\\Backup\\Notifications\\Notifiable',
      'mail' => 
      array (
        'to' => 'your@example.com',
        'from' => 
        array (
          'address' => 'hello@example.com',
          'name' => 'Admin Llorente Furniture',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => '',
        'channel' => NULL,
        'username' => NULL,
        'icon' => NULL,
      ),
      'discord' => 
      array (
        'webhook_url' => '',
        'username' => '',
        'avatar_url' => '',
      ),
    ),
    'monitor_backups' => 
    array (
      0 => 
      array (
        'name' => 'Admin Llorente Furniture',
        'disks' => 
        array (
          0 => 'local-backup',
        ),
        'health_checks' => 
        array (
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumAgeInDays' => 30,
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumStorageInMegabytes' => 5000,
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'default_strategy' => 
      array (
        'keep_all_backups_for_days' => 7,
        'keep_daily_backups_for_days' => 16,
        'keep_weekly_backups_for_weeks' => 8,
        'keep_monthly_backups_for_months' => 4,
        'keep_yearly_backups_for_years' => 2,
        'delete_oldest_backups_when_using_more_megabytes_than' => 5000,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'null',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'host' => 'api-mt1.pusher.com',
          'port' => '443',
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'array',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\laragon\\www\\qoqet\\storage\\framework/cache/data',
        'lock_path' => 'C:\\laragon\\www\\qoqet\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'admin_llorente_furniture_cache_',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'qoqet',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'qoqet',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'qoqet',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'qoqet',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'admin_llorente_furniture_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
      'horizon' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
        'options' => 
        array (
          'prefix' => 'admin_llorente_furniture_horizon:',
        ),
      ),
    ),
  ),
  'filament' => 
  array (
    'broadcasting' => 
    array (
    ),
    'default_filesystem_disk' => 'public-filament',
    'assets_path' => NULL,
  ),
  'filament-impersonate' => 
  array (
    'guard' => 'admin',
    'redirect_to' => 'admin',
    'leave_middleware' => 'web',
    'banner' => 
    array (
      'style' => 'dark',
      'fixed' => true,
      'position' => 'bottom',
      'styles' => 
      array (
        'light' => 
        array (
          'text' => '#1f2937',
          'background' => '#f3f4f6',
          'border' => '#e8eaec',
        ),
        'dark' => 
        array (
          'text' => '#f3f4f6',
          'background' => '#1f2937',
          'border' => '#374151',
        ),
      ),
    ),
  ),
  'filament-language-switch' => 
  array (
    'native' => true,
    'flag' => true,
    'locales' => 
    array (
      'ar' => 
      array (
        'name' => 'Arabic',
        'script' => 'Arab',
        'native' => 'العربية',
        'flag_code' => 'sa',
      ),
      'en' => 
      array (
        'name' => 'English',
        'script' => 'Latn',
        'native' => 'English',
        'flag_code' => 'us',
      ),
      'fr' => 
      array (
        'name' => 'French',
        'script' => 'Latn',
        'native' => 'français',
        'flag_code' => 'fr',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'sentry',
        'root' => 'C:\\laragon\\www\\qoqet\\storage\\app',
        'throw' => false,
        'sentry_disk_name' => 'local',
        'sentry_original_driver' => 'local',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'public' => 
      array (
        'driver' => 'sentry',
        'root' => 'C:\\laragon\\www\\qoqet\\storage\\app/public',
        'url' => 'http://127.0.0.1:8000/storage',
        'visibility' => 'public',
        'throw' => false,
        'sentry_disk_name' => 'public',
        'sentry_original_driver' => 'local',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      's3' => 
      array (
        'driver' => 'sentry',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'sentry_disk_name' => 's3',
        'sentry_original_driver' => 's3',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'prefix-local-backup' => 
      array (
        'driver' => 'sentry',
        'disk' => 'local',
        'prefix' => 'backup',
        'sentry_disk_name' => 'prefix-local-backup',
        'sentry_original_driver' => 'scoped',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'prefix-s3-backup' => 
      array (
        'driver' => 'sentry',
        'disk' => 's3',
        'prefix' => 'backup',
        'sentry_disk_name' => 'prefix-s3-backup',
        'sentry_original_driver' => 'scoped',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'prefix-public-filament' => 
      array (
        'driver' => 'sentry',
        'disk' => 'public',
        'prefix' => 'filament',
        'sentry_disk_name' => 'prefix-public-filament',
        'sentry_original_driver' => 'scoped',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'prefix-s3-filament' => 
      array (
        'driver' => 'sentry',
        'disk' => 's3',
        'prefix' => 'filament',
        'sentry_disk_name' => 'prefix-s3-filament',
        'sentry_original_driver' => 'scoped',
        'sentry_enable_spans' => true,
        'sentry_enable_breadcrumbs' => true,
      ),
      'filament-excel' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\laragon\\www\\qoqet\\storage\\app/filament-excel',
        'url' => 'http://127.0.0.1:8000/filament-excel',
      ),
    ),
    'links' => 
    array (
      'C:\\laragon\\www\\qoqet\\public\\storage' => 'C:\\laragon\\www\\qoqet\\storage\\app/public',
    ),
  ),
  'gravatar' => 
  array (
    'default' => 
    array (
      'size' => 80,
      'fallback' => 'wavatar',
      'secure' => false,
      'maximumRating' => 'g',
      'forceDefault' => false,
      'forceExtension' => 'jpg',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'health' => 
  array (
    'result_stores' => 
    array (
      'Spatie\\Health\\ResultStores\\EloquentHealthResultStore' => 
      array (
        'model' => 'Spatie\\Health\\Models\\HealthCheckResultHistoryItem',
        'keep_history_for_days' => 5,
      ),
    ),
    'notifications' => 
    array (
      'enabled' => true,
      'notifications' => 
      array (
        'Spatie\\Health\\Notifications\\CheckFailedNotification' => 
        array (
          0 => 'mail',
        ),
      ),
      'notifiable' => 'Spatie\\Health\\Notifications\\Notifiable',
      'throttle_notifications_for_minutes' => 60,
      'throttle_notifications_key' => 'health:latestNotificationSentAt:',
      'mail' => 
      array (
        'to' => 'your@example.com',
        'from' => 
        array (
          'address' => 'your@example.com',
          'name' => 'Admin Llorente Furniture',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => '',
        'channel' => NULL,
        'username' => NULL,
        'icon' => NULL,
      ),
    ),
    'oh_dear_endpoint' => 
    array (
      'enabled' => false,
      'always_send_fresh_results' => true,
      'secret' => NULL,
      'url' => '/oh-dear-health-check-results',
    ),
    'theme' => 'light',
    'silence_health_queue_job' => true,
  ),
  'horizon' => 
  array (
    'domain' => NULL,
    'path' => 'admin/horizon',
    'use' => 'default',
    'prefix' => 'admin_llorente_furniture_horizon:',
    'middleware' => 
    array (
      0 => 'web',
    ),
    'waits' => 
    array (
      'redis:default' => 60,
    ),
    'trim' => 
    array (
      'recent' => 60,
      'pending' => 60,
      'completed' => 60,
      'recent_failed' => 10080,
      'failed' => 10080,
      'monitored' => 10080,
    ),
    'silenced' => 
    array (
      0 => 'Spatie\\Health\\Jobs\\HealthQueueJob',
    ),
    'metrics' => 
    array (
      'trim_snapshots' => 
      array (
        'job' => 24,
        'queue' => 24,
      ),
    ),
    'fast_termination' => false,
    'memory_limit' => 64,
    'defaults' => 
    array (
      'supervisor-1' => 
      array (
        'connection' => 'redis',
        'queue' => 
        array (
          0 => 'default',
        ),
        'balance' => 'auto',
        'autoScalingStrategy' => 'time',
        'maxProcesses' => 1,
        'maxTime' => 0,
        'maxJobs' => 0,
        'memory' => 128,
        'tries' => 3,
        'timeout' => 60,
        'nice' => 0,
      ),
    ),
    'environments' => 
    array (
      'production' => 
      array (
        'supervisor-1' => 
        array (
          'maxProcesses' => 10,
          'balanceMaxShift' => 1,
          'balanceCooldown' => 3,
        ),
      ),
      'local' => 
      array (
        'supervisor-1' => 
        array (
          'maxProcesses' => 3,
        ),
      ),
    ),
  ),
  'ide-helper' => 
  array (
    'filename' => '_ide_helper.php',
    'models_filename' => '_ide_helper_models.php',
    'meta_filename' => '.phpstorm.meta.php',
    'include_fluent' => false,
    'include_factory_builders' => false,
    'write_model_magic_where' => true,
    'write_model_external_builder_methods' => true,
    'write_model_relation_count_properties' => true,
    'write_eloquent_model_mixins' => false,
    'include_helpers' => false,
    'helper_files' => 
    array (
      0 => 'C:\\laragon\\www\\qoqet/vendor/laravel/framework/src/Illuminate/Support/helpers.php',
    ),
    'model_locations' => 
    array (
      0 => 'app',
      1 => 'domain',
    ),
    'ignored_models' => 
    array (
    ),
    'model_hooks' => 
    array (
    ),
    'extra' => 
    array (
      'Eloquent' => 
      array (
        0 => 'Illuminate\\Database\\Eloquent\\Builder',
        1 => 'Illuminate\\Database\\Query\\Builder',
      ),
      'Session' => 
      array (
        0 => 'Illuminate\\Session\\Store',
      ),
    ),
    'magic' => 
    array (
    ),
    'interfaces' => 
    array (
    ),
    'custom_db_types' => 
    array (
    ),
    'model_camel_case_properties' => false,
    'type_overrides' => 
    array (
      'integer' => 'int',
      'boolean' => 'bool',
    ),
    'include_class_docblocks' => false,
    'force_fqn' => true,
    'use_generics_annotations' => true,
    'additional_relation_types' => 
    array (
    ),
    'additional_relation_return_types' => 
    array (
    ),
    'post_migrate' => 
    array (
    ),
  ),
  'inspector' => 
  array (
    'enable' => true,
    'key' => '',
    'url' => 'https://ingest.inspector.dev',
    'transport' => 'async',
    'max_items' => 100,
    'options' => 
    array (
    ),
    'query' => true,
    'bindings' => true,
    'user' => true,
    'email' => true,
    'notifications' => true,
    'views' => true,
    'job' => true,
    'redis' => true,
    'unhandled_exceptions' => false,
    'http_client' => true,
    'http_client_body' => false,
    'hidden_parameters' => 
    array (
      0 => 'password',
      1 => 'password_confirmation',
    ),
    'ignore_commands' => 
    array (
      0 => 'storage:link',
      1 => 'optimize',
      2 => 'optimize:clear',
      3 => 'schedule:run',
      4 => 'schedule:finish',
      5 => 'package:discover',
      6 => 'vendor:publish',
      7 => 'list',
      8 => 'test',
      9 => 'migrate',
      10 => 'migrate:rollback',
      11 => 'migrate:refresh',
      12 => 'migrate:fresh',
      13 => 'migrate:reset',
      14 => 'migrate:install',
      15 => 'cache:clear',
      16 => 'config:cache',
      17 => 'config:clear',
      18 => 'route:cache',
      19 => 'route:clear',
      20 => 'view:cache',
      21 => 'view:clear',
      22 => 'queue:listen',
      23 => 'queue:work',
      24 => 'queue:restart',
      25 => 'vapor:work',
      26 => 'horizon',
      27 => 'horizon:work',
      28 => 'horizon:supervisor',
      29 => 'horizon:terminate',
      30 => 'horizon:snapshot',
      31 => 'nova:publish',
      32 => 'up',
      33 => 'down',
      34 => 'event:cache',
      35 => 'settings:discover',
      36 => 'settings:cache',
      37 => 'settings:clear-cache',
      38 => 'settings:clear-discovered',
      39 => 'health:schedule-check-heartbeat',
      40 => 'health:queue-check-heartbeat',
      41 => 'app:permissions-sync',
      42 => 'app:time-out-logged-in-admins',
      43 => 'filament:upgrade',
      44 => 'l5-swagger:generate',
      45 => 'backup:monitor',
      46 => 'filament-excel:prune',
      47 => 'about',
    ),
    'ignore_url' => 
    array (
      0 => 'telescope*',
      1 => 'vendor/telescope*',
      2 => 'admin/horizon*',
      3 => 'vendor/horizon*',
      4 => 'nova*',
      5 => 'livewire*',
      6 => 'filament*',
      7 => 'admin/log-viewer*',
    ),
    'ignore_jobs' => 
    array (
      0 => 'Spatie\\Health\\Jobs\\HealthQueueJob',
      1 => 'ShuvroRoy\\FilamentSpatieLaravelBackup\\Jobs\\CreateBackupJob',
    ),
  ),
  'log-viewer' => 
  array (
    'enabled' => true,
    'route_domain' => NULL,
    'route_path' => 'admin/log-viewer',
    'back_to_system_url' => 'http://127.0.0.1:8000',
    'back_to_system_label' => NULL,
    'timezone' => 'asia/manila',
    'middleware' => 
    array (
      0 => 'web',
      1 => 'Opcodes\\LogViewer\\Http\\Middleware\\AuthorizeLogViewer',
    ),
    'api_middleware' => 
    array (
      0 => 'Opcodes\\LogViewer\\Http\\Middleware\\EnsureFrontendRequestsAreStateful',
      1 => 'Opcodes\\LogViewer\\Http\\Middleware\\AuthorizeLogViewer',
    ),
    'hosts' => 
    array (
      'local' => 
      array (
        'name' => 'Local',
      ),
    ),
    'include_files' => 
    array (
      0 => '*.log',
      1 => '**/*.log',
      2 => '/var/log/httpd/*',
      3 => '/opt/homebrew/var/log/nginx/*',
      4 => '/opt/homebrew/var/log/httpd/*',
      5 => '/opt/homebrew/var/log/php-fpm.log',
      6 => '/opt/homebrew/var/log/postgres*log',
      7 => '/opt/homebrew/var/log/redis*log',
      8 => '/opt/homebrew/var/log/supervisor*log',
    ),
    'exclude_files' => 
    array (
    ),
    'hide_unknown_files' => true,
    'shorter_stack_trace_excludes' => 
    array (
      0 => '/vendor/symfony/',
      1 => '/vendor/laravel/framework/',
      2 => '/vendor/barryvdh/laravel-debugbar/',
    ),
    'cache_driver' => NULL,
    'lazy_scan_chunk_size_in_mb' => 50,
    'strip_extracted_context' => true,
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => 'null',
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
          1 => 'sentry',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\laragon\\www\\qoqet\\storage\\logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\laragon\\www\\qoqet\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\laragon\\www\\qoqet\\storage\\logs/laravel.log',
      ),
      'sentry' => 
      array (
        'driver' => 'sentry',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'url' => NULL,
        'host' => 'smtp.mailgun.org',
        'port' => 587,
        'encryption' => 'tls',
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
      'helo' => 
      array (
        'transport' => 'smtp',
        'host' => '10.0.2.2',
        'port' => 2525,
        'encryption' => NULL,
        'username' => 'Admin Llorente Furniture',
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\laragon\\www\\qoqet\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'media-library' => 
  array (
    'disk_name' => 'public',
    'max_file_size' => 10485760,
    'queue_connection_name' => 'sync',
    'queue_name' => '',
    'queue_conversions_by_default' => true,
    'media_model' => 'Spatie\\MediaLibrary\\MediaCollections\\Models\\Media',
    'use_default_collection_serialization' => false,
    'temporary_upload_model' => 'Spatie\\MediaLibraryPro\\Models\\TemporaryUpload',
    'enable_temporary_uploads_session_affinity' => true,
    'generate_thumbnails_for_temporary_uploads' => true,
    'file_namer' => 'Spatie\\MediaLibrary\\Support\\FileNamer\\DefaultFileNamer',
    'path_generator' => 'Spatie\\MediaLibrary\\Support\\PathGenerator\\DefaultPathGenerator',
    'custom_path_generators' => 
    array (
    ),
    'url_generator' => 'Spatie\\MediaLibrary\\Support\\UrlGenerator\\DefaultUrlGenerator',
    'moves_media_on_update' => false,
    'version_urls' => true,
    'image_optimizers' => 
    array (
      'Spatie\\ImageOptimizer\\Optimizers\\Jpegoptim' => 
      array (
        0 => '-m85',
        1 => '--force',
        2 => '--strip-all',
        3 => '--all-progressive',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Pngquant' => 
      array (
        0 => '--force',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Optipng' => 
      array (
        0 => '-i0',
        1 => '-o2',
        2 => '-quiet',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Svgo' => 
      array (
        0 => '--disable=cleanupIDs',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Gifsicle' => 
      array (
        0 => '-b',
        1 => '-O3',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Cwebp' => 
      array (
        0 => '-m 6',
        1 => '-pass 10',
        2 => '-mt',
        3 => '-q 90',
      ),
    ),
    'image_generators' => 
    array (
      0 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Image',
      1 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Webp',
      2 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Pdf',
      3 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Svg',
      4 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Video',
    ),
    'temporary_directory_path' => NULL,
    'image_driver' => 'gd',
    'ffmpeg_path' => '/usr/bin/ffmpeg',
    'ffprobe_path' => '/usr/bin/ffprobe',
    'jobs' => 
    array (
      'perform_conversions' => 'Spatie\\MediaLibrary\\Conversions\\Jobs\\PerformConversionsJob',
      'generate_responsive_images' => 'Spatie\\MediaLibrary\\ResponsiveImages\\Jobs\\GenerateResponsiveImagesJob',
    ),
    'media_downloader' => 'Spatie\\MediaLibrary\\Downloaders\\DefaultDownloader',
    'remote' => 
    array (
      'extra_headers' => 
      array (
        'CacheControl' => 'max-age=604800',
      ),
    ),
    'responsive_images' => 
    array (
      'width_calculator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\WidthCalculator\\FileSizeOptimizedWidthCalculator',
      'use_tiny_placeholders' => true,
      'tiny_placeholder_generator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\TinyPlaceholderGenerator\\Blurred',
    ),
    'enable_vapor_uploads' => false,
    'default_loading_attribute_value' => NULL,
    'prefix' => 'media',
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Domain\\Access\\Role\\Models\\Permission',
      'role' => 'Domain\\Access\\Role\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'permissions_roles',
      'permissions' => 'permissions_permissions',
      'model_has_permissions' => 'permissions_model_has_permissions',
      'model_has_roles' => 'permissions_model_has_roles',
      'role_has_permissions' => 'permissions_role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'teams' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => true,
    'cache' => 
    array (
      'expiration_time' => 
      \DateInterval::__set_state(array(
         'from_string' => true,
         'date_string' => '24 hours',
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'queue_jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'queue_job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'queue_failed_jobs',
    ),
  ),
  'route-attributes' => 
  array (
    'enabled' => true,
    'directories' => 
    array (
      'C:\\laragon\\www\\qoqet\\app\\Http/Controllers/API' => 
      array (
        'as' => 'api.',
        'prefix' => 'api',
        'middleware' => 'api',
      ),
    ),
    'middleware' => 
    array (
      0 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => '127.0.0.1:8000',
    ),
    'guard' => 
    array (
      0 => 'api',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'scramble' => 
  array (
    'api_path' => 'api',
    'api_domain' => NULL,
    'info' => 
    array (
      'version' => '0.0.1',
      'description' => '',
    ),
    'ui' => 
    array (
      'hide_try_it' => false,
      'logo' => '',
    ),
    'servers' => NULL,
    'middleware' => 
    array (
      0 => 'web',
    ),
    'extensions' => 
    array (
    ),
  ),
  'seeder' => 
  array (
    'admin_hash_password' => '$2y$10$30Em8lVElUcSk/CKIbqsqO6SFLVXOsUsYbwG4J3BiXMoPoYH8EXJS',
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\laragon\\www\\qoqet\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'admin_llorente_furniture_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'settings' => 
  array (
    'settings' => 
    array (
    ),
    'setting_class_path' => 'C:\\laragon\\www\\qoqet\\app\\Settings',
    'migrations_paths' => 
    array (
      0 => 'C:\\laragon\\www\\qoqet\\database\\settings',
    ),
    'default_repository' => 'database',
    'repositories' => 
    array (
      'database' => 
      array (
        'type' => 'Spatie\\LaravelSettings\\SettingsRepositories\\DatabaseSettingsRepository',
        'model' => NULL,
        'table' => NULL,
        'connection' => NULL,
      ),
      'redis' => 
      array (
        'type' => 'Spatie\\LaravelSettings\\SettingsRepositories\\RedisSettingsRepository',
        'connection' => NULL,
        'prefix' => NULL,
      ),
    ),
    'cache' => 
    array (
      'enabled' => false,
      'store' => NULL,
      'prefix' => NULL,
      'ttl' => NULL,
    ),
    'global_casts' => 
    array (
      'DateTimeInterface' => 'Spatie\\LaravelSettings\\SettingsCasts\\DateTimeInterfaceCast',
      'DateTimeZone' => 'Spatie\\LaravelSettings\\SettingsCasts\\DateTimeZoneCast',
    ),
    'auto_discover_settings' => 
    array (
      0 => 'C:\\laragon\\www\\qoqet\\app\\Settings',
    ),
    'discovered_settings_cache_path' => 'C:\\laragon\\www\\qoqet\\bootstrap/cache',
  ),
  'support-bubble' => 
  array (
    'fields' => 
    array (
      'name' => true,
      'email' => true,
      'subject' => true,
      'message' => true,
    ),
    'mail_to' => NULL,
    'prefill_logged_in_user' => true,
    'classes' => 
    array (
      'container' => 'text-base items-end z-30 flex-col m-4 gap-3',
      'bubble' => 'hidden sm:block | bg-purple-400 rounded-full shadow-lg w-14 h-14 text-white p-4',
      'input' => 'bg-gray-100 border border-gray-200 w-full max-w-full p-2 rounded-sm shadow-input text-gray-800 text-base',
      'button' => 'inline-block place-center px-4 py-3 h-10 border-0 bg-purple-500 hover:bg-purple-600 active:bg-purple-600 overflow-hidden rounded-sm text-white leading-none no-underline',
      'label' => 'text-gray-800',
    ),
    'form_action_route' => 'supportBubble.submit',
    'direction' => 'left-to-right',
  ),
  'telescope' => 
  array (
    'domain' => NULL,
    'path' => 'admin/telescope',
    'driver' => 'database',
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
        'chunk' => 1000,
      ),
    ),
    'enabled' => false,
    'middleware' => 
    array (
      0 => 'web',
      1 => 'Laravel\\Telescope\\Http\\Middleware\\Authorize',
    ),
    'only_paths' => 
    array (
    ),
    'ignore_paths' => 
    array (
      0 => 'nova-api*',
      1 => 'livewire*',
    ),
    'ignore_commands' => 
    array (
    ),
    'watchers' => 
    array (
      'Laravel\\Telescope\\Watchers\\BatchWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CacheWatcher' => 
      array (
        'enabled' => true,
        'hidden' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ClientRequestWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CommandWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\DumpWatcher' => 
      array (
        'enabled' => true,
        'always' => false,
      ),
      'Laravel\\Telescope\\Watchers\\EventWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ExceptionWatcher' => true,
      'Laravel\\Telescope\\Watchers\\GateWatcher' => 
      array (
        'enabled' => true,
        'ignore_abilities' => 
        array (
        ),
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\JobWatcher' => true,
      'Laravel\\Telescope\\Watchers\\LogWatcher' => 
      array (
        'enabled' => true,
        'level' => 'error',
      ),
      'Laravel\\Telescope\\Watchers\\MailWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ModelWatcher' => 
      array (
        'enabled' => true,
        'events' => 
        array (
          0 => 'eloquent.*',
        ),
        'hydrations' => true,
      ),
      'Laravel\\Telescope\\Watchers\\NotificationWatcher' => true,
      'Laravel\\Telescope\\Watchers\\QueryWatcher' => 
      array (
        'enabled' => true,
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
        'slow' => 100,
      ),
      'Laravel\\Telescope\\Watchers\\RedisWatcher' => true,
      'Laravel\\Telescope\\Watchers\\RequestWatcher' => 
      array (
        'enabled' => true,
        'size_limit' => 64,
        'ignore_http_methods' => 
        array (
        ),
        'ignore_status_codes' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ScheduleWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ViewWatcher' => true,
    ),
  ),
  'themes' => 
  array (
    'mode' => 'user',
    'icon' => 'heroicon-o-swatch',
    'default' => 
    array (
      'theme' => 'default',
      'theme_color' => 'blue',
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\laragon\\www\\qoqet\\resources\\views',
    ),
    'compiled' => 'C:\\laragon\\www\\qoqet\\storage\\framework\\views',
  ),
  'money' => 
  array (
    'defaults' => 
    array (
      'currency' => 'USD',
      'convert' => false,
    ),
    'currencies' => 
    array (
      'AED' => 
      array (
        'name' => 'UAE Dirham',
        'code' => 784,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'د.إ',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'AFN' => 
      array (
        'name' => 'Afghani',
        'code' => 971,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '؋',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ALL' => 
      array (
        'name' => 'Lek',
        'code' => 8,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'L',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'AMD' => 
      array (
        'name' => 'Armenian Dram',
        'code' => 51,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'դր.',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ANG' => 
      array (
        'name' => 'Netherlands Antillean Guilder',
        'code' => 532,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ƒ',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'AOA' => 
      array (
        'name' => 'Kwanza',
        'code' => 973,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Kz',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ARS' => 
      array (
        'name' => 'Argentine Peso',
        'code' => 32,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'AUD' => 
      array (
        'name' => 'Australian Dollar',
        'code' => 36,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ' ',
      ),
      'AWG' => 
      array (
        'name' => 'Aruban Florin',
        'code' => 533,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ƒ',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'AZN' => 
      array (
        'name' => 'Azerbaijanian Manat',
        'code' => 944,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₼',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BAM' => 
      array (
        'name' => 'Convertible Mark',
        'code' => 977,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'КМ',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BBD' => 
      array (
        'name' => 'Barbados Dollar',
        'code' => 52,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BDT' => 
      array (
        'name' => 'Taka',
        'code' => 50,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '৳',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BGN' => 
      array (
        'name' => 'Bulgarian Lev',
        'code' => 975,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'лв',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => ' ',
      ),
      'BHD' => 
      array (
        'name' => 'Bahraini Dinar',
        'code' => 48,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'ب.د',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BIF' => 
      array (
        'name' => 'Burundi Franc',
        'code' => 108,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BMD' => 
      array (
        'name' => 'Bermudian Dollar',
        'code' => 60,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BND' => 
      array (
        'name' => 'Brunei Dollar',
        'code' => 96,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BOB' => 
      array (
        'name' => 'Boliviano',
        'code' => 68,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Bs.',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BOV' => 
      array (
        'name' => 'Mvdol',
        'code' => 984,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Bs.',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BRL' => 
      array (
        'name' => 'Brazilian Real',
        'code' => 986,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'R$',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'BSD' => 
      array (
        'name' => 'Bahamian Dollar',
        'code' => 44,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BTN' => 
      array (
        'name' => 'Ngultrum',
        'code' => 64,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Nu.',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BWP' => 
      array (
        'name' => 'Pula',
        'code' => 72,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'P',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'BYN' => 
      array (
        'name' => 'Belarussian Ruble',
        'code' => 974,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Br',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => ' ',
      ),
      'BZD' => 
      array (
        'name' => 'Belize Dollar',
        'code' => 84,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CAD' => 
      array (
        'name' => 'Canadian Dollar',
        'code' => 124,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CDF' => 
      array (
        'name' => 'Congolese Franc',
        'code' => 976,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CHF' => 
      array (
        'name' => 'Swiss Franc',
        'code' => 756,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'CHF',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CLF' => 
      array (
        'name' => 'Unidades de fomento',
        'code' => 990,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'UF',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'CLP' => 
      array (
        'name' => 'Chilean Peso',
        'code' => 152,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'CNY' => 
      array (
        'name' => 'Yuan Renminbi',
        'code' => 156,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '¥',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'COP' => 
      array (
        'name' => 'Colombian Peso',
        'code' => 170,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'CRC' => 
      array (
        'name' => 'Costa Rican Colon',
        'code' => 188,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₡',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'CUC' => 
      array (
        'name' => 'Peso Convertible',
        'code' => 931,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CUP' => 
      array (
        'name' => 'Cuban Peso',
        'code' => 192,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CVE' => 
      array (
        'name' => 'Cape Verde Escudo',
        'code' => 132,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'CZK' => 
      array (
        'name' => 'Czech Koruna',
        'code' => 203,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Kč',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'DJF' => 
      array (
        'name' => 'Djibouti Franc',
        'code' => 262,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fdj',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'DKK' => 
      array (
        'name' => 'Danish Krone',
        'code' => 208,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'kr',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'DOP' => 
      array (
        'name' => 'Dominican Peso',
        'code' => 214,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'DZD' => 
      array (
        'name' => 'Algerian Dinar',
        'code' => 12,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'د.ج',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'EGP' => 
      array (
        'name' => 'Egyptian Pound',
        'code' => 818,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ج.م',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ERN' => 
      array (
        'name' => 'Nakfa',
        'code' => 232,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Nfk',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ETB' => 
      array (
        'name' => 'Ethiopian Birr',
        'code' => 230,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Br',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'EUR' => 
      array (
        'name' => 'Euro',
        'code' => 978,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '€',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'FJD' => 
      array (
        'name' => 'Fiji Dollar',
        'code' => 242,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'FKP' => 
      array (
        'name' => 'Falkland Islands Pound',
        'code' => 238,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GBP' => 
      array (
        'name' => 'Pound Sterling',
        'code' => 826,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GEL' => 
      array (
        'name' => 'Lari',
        'code' => 981,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₾',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GHS' => 
      array (
        'name' => 'Ghana Cedi',
        'code' => 936,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₵',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GIP' => 
      array (
        'name' => 'Gibraltar Pound',
        'code' => 292,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GMD' => 
      array (
        'name' => 'Dalasi',
        'code' => 270,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'D',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GNF' => 
      array (
        'name' => 'Guinea Franc',
        'code' => 324,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GTQ' => 
      array (
        'name' => 'Quetzal',
        'code' => 320,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Q',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'GYD' => 
      array (
        'name' => 'Guyana Dollar',
        'code' => 328,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'HKD' => 
      array (
        'name' => 'Hong Kong Dollar',
        'code' => 344,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'HNL' => 
      array (
        'name' => 'Lempira',
        'code' => 340,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'L',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'HRK' => 
      array (
        'name' => 'Croatian Kuna',
        'code' => 191,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'kn',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'HTG' => 
      array (
        'name' => 'Gourde',
        'code' => 332,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'G',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'HUF' => 
      array (
        'name' => 'Forint',
        'code' => 348,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Ft',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'IDR' => 
      array (
        'name' => 'Rupiah',
        'code' => 360,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Rp',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'ILS' => 
      array (
        'name' => 'New Israeli Sheqel',
        'code' => 376,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₪',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'INR' => 
      array (
        'name' => 'Indian Rupee',
        'code' => 356,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₹',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'IQD' => 
      array (
        'name' => 'Iraqi Dinar',
        'code' => 368,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'ع.د',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'IRR' => 
      array (
        'name' => 'Iranian Rial',
        'code' => 364,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '﷼',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ISK' => 
      array (
        'name' => 'Iceland Krona',
        'code' => 352,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'kr',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'JMD' => 
      array (
        'name' => 'Jamaican Dollar',
        'code' => 388,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'JOD' => 
      array (
        'name' => 'Jordanian Dinar',
        'code' => 400,
        'precision' => 3,
        'subunit' => 100,
        'symbol' => 'د.ا',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'JPY' => 
      array (
        'name' => 'Yen',
        'code' => 392,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => '¥',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KES' => 
      array (
        'name' => 'Kenyan Shilling',
        'code' => 404,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'KSh',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KGS' => 
      array (
        'name' => 'Som',
        'code' => 417,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'som',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KHR' => 
      array (
        'name' => 'Riel',
        'code' => 116,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '៛',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KMF' => 
      array (
        'name' => 'Comoro Franc',
        'code' => 174,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KPW' => 
      array (
        'name' => 'North Korean Won',
        'code' => 408,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₩',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KRW' => 
      array (
        'name' => 'Won',
        'code' => 410,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => '₩',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KWD' => 
      array (
        'name' => 'Kuwaiti Dinar',
        'code' => 414,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'د.ك',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KYD' => 
      array (
        'name' => 'Cayman Islands Dollar',
        'code' => 136,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'KZT' => 
      array (
        'name' => 'Tenge',
        'code' => 398,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '〒',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LAK' => 
      array (
        'name' => 'Kip',
        'code' => 418,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₭',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LBP' => 
      array (
        'name' => 'Lebanese Pound',
        'code' => 422,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ل.ل',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LKR' => 
      array (
        'name' => 'Sri Lanka Rupee',
        'code' => 144,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₨',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LRD' => 
      array (
        'name' => 'Liberian Dollar',
        'code' => 430,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LSL' => 
      array (
        'name' => 'Loti',
        'code' => 426,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'L',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LTL' => 
      array (
        'name' => 'Lithuanian Litas',
        'code' => 440,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Lt',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LVL' => 
      array (
        'name' => 'Latvian Lats',
        'code' => 428,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Ls',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'LYD' => 
      array (
        'name' => 'Libyan Dinar',
        'code' => 434,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'ل.د',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MAD' => 
      array (
        'name' => 'Moroccan Dirham',
        'code' => 504,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'د.م.',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MDL' => 
      array (
        'name' => 'Moldovan Leu',
        'code' => 498,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'L',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MGA' => 
      array (
        'name' => 'Malagasy Ariary',
        'code' => 969,
        'precision' => 2,
        'subunit' => 5,
        'symbol' => 'Ar',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MKD' => 
      array (
        'name' => 'Denar',
        'code' => 807,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ден',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MMK' => 
      array (
        'name' => 'Kyat',
        'code' => 104,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'K',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MNT' => 
      array (
        'name' => 'Tugrik',
        'code' => 496,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₮',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MOP' => 
      array (
        'name' => 'Pataca',
        'code' => 446,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'P',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MRO' => 
      array (
        'name' => 'Ouguiya',
        'code' => 478,
        'precision' => 2,
        'subunit' => 5,
        'symbol' => 'UM',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MUR' => 
      array (
        'name' => 'Mauritius Rupee',
        'code' => 480,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₨',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MVR' => 
      array (
        'name' => 'Rufiyaa',
        'code' => 462,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'MVR',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MWK' => 
      array (
        'name' => 'Kwacha',
        'code' => 454,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'MK',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MXN' => 
      array (
        'name' => 'Mexican Peso',
        'code' => 484,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MYR' => 
      array (
        'name' => 'Malaysian Ringgit',
        'code' => 458,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'RM',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'MZN' => 
      array (
        'name' => 'Mozambique Metical',
        'code' => 943,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'MTn',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'NAD' => 
      array (
        'name' => 'Namibia Dollar',
        'code' => 516,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'NGN' => 
      array (
        'name' => 'Naira',
        'code' => 566,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₦',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'NIO' => 
      array (
        'name' => 'Cordoba Oro',
        'code' => 558,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'C$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'NOK' => 
      array (
        'name' => 'Norwegian Krone',
        'code' => 578,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'kr',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'NPR' => 
      array (
        'name' => 'Nepalese Rupee',
        'code' => 524,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₨',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'NZD' => 
      array (
        'name' => 'New Zealand Dollar',
        'code' => 554,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'OMR' => 
      array (
        'name' => 'Rial Omani',
        'code' => 512,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'ر.ع.',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PAB' => 
      array (
        'name' => 'Balboa',
        'code' => 590,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'B/.',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PEN' => 
      array (
        'name' => 'Sol',
        'code' => 604,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'S/',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PGK' => 
      array (
        'name' => 'Kina',
        'code' => 598,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'K',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PHP' => 
      array (
        'name' => 'Philippine Peso',
        'code' => 608,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₱',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PKR' => 
      array (
        'name' => 'Pakistan Rupee',
        'code' => 586,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₨',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'PLN' => 
      array (
        'name' => 'Zloty',
        'code' => 985,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'zł',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => ' ',
      ),
      'PYG' => 
      array (
        'name' => 'Guarani',
        'code' => 600,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => '₲',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'QAR' => 
      array (
        'name' => 'Qatari Rial',
        'code' => 634,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ر.ق',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'RON' => 
      array (
        'name' => 'New Romanian Leu',
        'code' => 946,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Lei',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'RSD' => 
      array (
        'name' => 'Serbian Dinar',
        'code' => 941,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'РСД',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'RUB' => 
      array (
        'name' => 'Russian Ruble',
        'code' => 643,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₽',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'RWF' => 
      array (
        'name' => 'Rwanda Franc',
        'code' => 646,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'FRw',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SAR' => 
      array (
        'name' => 'Saudi Riyal',
        'code' => 682,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ر.س',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SBD' => 
      array (
        'name' => 'Solomon Islands Dollar',
        'code' => 90,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SCR' => 
      array (
        'name' => 'Seychelles Rupee',
        'code' => 690,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₨',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SDG' => 
      array (
        'name' => 'Sudanese Pound',
        'code' => 938,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SEK' => 
      array (
        'name' => 'Swedish Krona',
        'code' => 752,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'kr',
        'symbol_first' => false,
        'decimal_mark' => ',',
        'thousands_separator' => ' ',
      ),
      'SGD' => 
      array (
        'name' => 'Singapore Dollar',
        'code' => 702,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SHP' => 
      array (
        'name' => 'Saint Helena Pound',
        'code' => 654,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SLL' => 
      array (
        'name' => 'Leone',
        'code' => 694,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Le',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SOS' => 
      array (
        'name' => 'Somali Shilling',
        'code' => 706,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Sh',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SRD' => 
      array (
        'name' => 'Surinam Dollar',
        'code' => 968,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SSP' => 
      array (
        'name' => 'South Sudanese Pound',
        'code' => 728,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'STD' => 
      array (
        'name' => 'Dobra',
        'code' => 678,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Db',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SVC' => 
      array (
        'name' => 'El Salvador Colon',
        'code' => 222,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₡',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SYP' => 
      array (
        'name' => 'Syrian Pound',
        'code' => 760,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '£S',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'SZL' => 
      array (
        'name' => 'Lilangeni',
        'code' => 748,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'E',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'THB' => 
      array (
        'name' => 'Baht',
        'code' => 764,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '฿',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TJS' => 
      array (
        'name' => 'Somoni',
        'code' => 972,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ЅМ',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TMT' => 
      array (
        'name' => 'Turkmenistan New Manat',
        'code' => 934,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'T',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TND' => 
      array (
        'name' => 'Tunisian Dinar',
        'code' => 788,
        'precision' => 3,
        'subunit' => 1000,
        'symbol' => 'د.ت',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TOP' => 
      array (
        'name' => 'Pa’anga',
        'code' => 776,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'T$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TRY' => 
      array (
        'name' => 'Turkish Lira',
        'code' => 949,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₺',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'TTD' => 
      array (
        'name' => 'Trinidad and Tobago Dollar',
        'code' => 780,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TWD' => 
      array (
        'name' => 'New Taiwan Dollar',
        'code' => 901,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'TZS' => 
      array (
        'name' => 'Tanzanian Shilling',
        'code' => 834,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Sh',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'UAH' => 
      array (
        'name' => 'Hryvnia',
        'code' => 980,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '₴',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'UGX' => 
      array (
        'name' => 'Uganda Shilling',
        'code' => 800,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'USh',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'USD' => 
      array (
        'name' => 'US Dollar',
        'code' => 840,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'UYU' => 
      array (
        'name' => 'Peso Uruguayo',
        'code' => 858,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'UZS' => 
      array (
        'name' => 'Uzbekistan Sum',
        'code' => 860,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'лв',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'VEF' => 
      array (
        'name' => 'Bolivar',
        'code' => 937,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'Bs F',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'VND' => 
      array (
        'name' => 'Dong',
        'code' => 704,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => '₫',
        'symbol_first' => true,
        'decimal_mark' => ',',
        'thousands_separator' => '.',
      ),
      'VUV' => 
      array (
        'name' => 'Vatu',
        'code' => 548,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Vt',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'WST' => 
      array (
        'name' => 'Tala',
        'code' => 882,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'T',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XAF' => 
      array (
        'name' => 'CFA Franc BEAC',
        'code' => 950,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XAG' => 
      array (
        'name' => 'Silver',
        'code' => 961,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'oz t',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XAU' => 
      array (
        'name' => 'Gold',
        'code' => 959,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'oz t',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XCD' => 
      array (
        'name' => 'East Caribbean Dollar',
        'code' => 951,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XDR' => 
      array (
        'name' => 'SDR (Special Drawing Right)',
        'code' => 960,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'SDR',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XOF' => 
      array (
        'name' => 'CFA Franc BCEAO',
        'code' => 952,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'XPF' => 
      array (
        'name' => 'CFP Franc',
        'code' => 953,
        'precision' => 0,
        'subunit' => 1,
        'symbol' => 'Fr',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'YER' => 
      array (
        'name' => 'Yemeni Rial',
        'code' => 886,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '﷼',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ZAR' => 
      array (
        'name' => 'Rand',
        'code' => 710,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'R',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ZMW' => 
      array (
        'name' => 'Zambian Kwacha',
        'code' => 967,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => 'ZK',
        'symbol_first' => false,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
      'ZWL' => 
      array (
        'name' => 'Zimbabwe Dollar',
        'code' => 932,
        'precision' => 2,
        'subunit' => 100,
        'symbol' => '$',
        'symbol_first' => true,
        'decimal_mark' => '.',
        'thousands_separator' => ',',
      ),
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => false,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'open' => false,
      'driver' => 'file',
      'path' => 'C:\\laragon\\www\\qoqet\\storage\\debugbar',
      'connection' => NULL,
      'provider' => '',
      'hostname' => '127.0.0.1',
      'port' => 2304,
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
      'livewire' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'backtrace_exclude_paths' => 
        array (
        ),
        'timeline' => false,
        'duration_background' => true,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => false,
        'show_copy' => false,
        'slow_threshold' => false,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'timeline' => false,
        'data' => false,
        'exclude_paths' => 
        array (
        ),
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'blade-heroicons' => 
  array (
    'prefix' => 'heroicon',
    'fallback' => '',
    'class' => '',
    'attributes' => 
    array (
    ),
  ),
  'blade-icons' => 
  array (
    'sets' => 
    array (
    ),
    'class' => '',
    'attributes' => 
    array (
    ),
    'fallback' => '',
    'components' => 
    array (
      'disabled' => false,
      'default' => 'icon',
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'laravel-impersonate' => 
  array (
    'session_key' => 'impersonated_by',
    'session_guard' => 'impersonator_guard',
    'session_guard_using' => 'impersonator_guard_using',
    'default_impersonator_guard' => 'web',
    'take_redirect_to' => '/',
    'leave_redirect_to' => '/',
  ),
  'livewire' => 
  array (
    'class_namespace' => 'App\\Livewire',
    'view_path' => 'C:\\laragon\\www\\qoqet\\resources\\views/livewire',
    'layout' => 'components.layouts.app',
    'lazy_placeholder' => NULL,
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => false,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
      'progress_bar_color' => '#2299dd',
    ),
    'inject_morph_markers' => true,
    'pagination_theme' => 'tailwind',
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
        'output_encoding' => '',
        'test_auto_detect' => true,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => NULL,
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
      'db' => 
      array (
        'connection' => NULL,
      ),
    ),
    'temporary_files' => 
    array (
      'local_path' => 'C:\\laragon\\www\\qoqet\\storage\\framework/cache/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'sentry' => 
  array (
    'dsn' => '',
    'release' => NULL,
    'environment' => NULL,
    'sample_rate' => 1.0,
    'traces_sample_rate' => NULL,
    'profiles_sample_rate' => NULL,
    'send_default_pii' => false,
    'breadcrumbs' => 
    array (
      'logs' => true,
      'cache' => true,
      'livewire' => true,
      'sql_queries' => true,
      'sql_bindings' => false,
      'queue_info' => true,
      'command_info' => true,
      'http_client_requests' => true,
    ),
    'tracing' => 
    array (
      'queue_job_transactions' => false,
      'queue_jobs' => true,
      'sql_queries' => true,
      'sql_origin' => true,
      'views' => true,
      'livewire' => true,
      'http_client_requests' => true,
      'redis_commands' => false,
      'redis_origin' => true,
      'missing_routes' => false,
      'continue_after_response' => true,
      'default_integrations' => true,
    ),
  ),
  'eloquent-sortable' => 
  array (
    'order_column_name' => 'order_column',
    'sort_when_creating' => true,
  ),
  'activitylog' => 
  array (
    'enabled' => true,
    'delete_records_older_than_days' => 365,
    'default_log_name' => 'default',
    'default_auth_driver' => NULL,
    'subject_returns_soft_deleted_models' => false,
    'activity_model' => 'Spatie\\Activitylog\\Models\\Activity',
    'table_name' => 'activity_log',
    'database_connection' => NULL,
  ),
  'honeypot' => 
  array (
    'enabled' => true,
    'name_field_name' => 'my_name',
    'randomize_name_field_name' => true,
    'valid_from_timestamp' => true,
    'valid_from_field_name' => 'valid_from',
    'amount_of_seconds' => 3,
    'respond_to_spam_with' => 'Spatie\\Honeypot\\SpamResponder\\BlankPageResponder',
    'honeypot_fields_required_for_all_forms' => false,
    'spam_protection' => 'Spatie\\Honeypot\\SpamProtection',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'json-api-paginate' => 
  array (
    'max_results' => 30,
    'default_size' => 30,
    'number_parameter' => 'number',
    'size_parameter' => 'size',
    'cursor_parameter' => 'cursor',
    'method_name' => 'jsonPaginate',
    'use_simple_pagination' => false,
    'use_cursor_pagination' => false,
    'base_url' => NULL,
    'pagination_parameter' => 'page',
  ),
  'query-builder' => 
  array (
    'parameters' => 
    array (
      'include' => 'include',
      'filter' => 'filter',
      'sort' => 'sort',
      'fields' => 'fields',
      'append' => 'append',
    ),
    'count_suffix' => 'Count',
    'exists_suffix' => 'Exists',
    'disable_invalid_filter_query_exception' => false,
    'disable_invalid_sort_query_exception' => false,
  ),
  'blade-country-flags' => 
  array (
    'prefix' => 'flag',
    'fallback' => '',
    'class' => '',
    'attributes' => 
    array (
    ),
  ),
  'domain' => 
  array (
    'access' => 
    array (
      'role' => 
      array (
        'super_admin' => 'super_admin',
        'admin' => 'admin',
        'branch' => 'branch',
      ),
    ),
    'shop' => 
    array (
      'order' => 
      array (
      ),
    ),
  ),
  'request-factories' => 
  array (
    'path' => NULL,
    'namespace' => 'Tests\\RequestFactories',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
