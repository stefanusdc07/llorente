<p align="left"></p>

###

<br clear="both">

<h2 align="left">Llorente Ecommerce Project by Tokomob.net Team</h2>

###

<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="40" alt="javascript logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain.svg" height="40" alt="laravel logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/tailwindcss/tailwindcss-original-wordmark.svg" height="40" alt="tailwindcss logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" height="40" alt="php logo"  />
  <img width="12" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" height="40" alt="nodejs logo"  />
</div>

###

<img src="https://raw.githubusercontent.com/stefanusdc07/stefanusdc07/output/snake.svg" alt="Snake animation" />

###

<div align="left">
  <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/linkedin/default.svg" width="52" height="40" alt="linkedin logo"  />
  <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/youtube/default.svg" width="52" height="40" alt="youtube logo"  />
  <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/instagram/default.svg" width="52" height="40" alt="instagram logo"  />
  <img src="https://raw.githubusercontent.com/maurodesouza/profile-readme-generator/master/src/assets/icons/social/facebook/default.svg" width="52" height="40" alt="facebook logo"  />
</div>

###

<h2 align="center">Progress:</h2>

###

<p align="left">Manajemen Produk:</p>

###

<div align="center">
  <img height="200" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgQZab-d6tnN4D1g_iHkzEvh75XF8Q7Y0xV1IXF5zU-PnuuDECAMpOcyCvAy80CXlZQfg&usqp=CAU"  />
</div>

###

<p align="left">Manajemen Kategori:</p>

###

<div align="center">
  <img height="200" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgQZab-d6tnN4D1g_iHkzEvh75XF8Q7Y0xV1IXF5zU-PnuuDECAMpOcyCvAy80CXlZQfg&usqp=CAU"  />
</div>

###

<p align="left">Manajemen Customer:</p>

###

<div align="center">
  <img height="200" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRksDezkA7S80qfdJT1Ef5DwpEompUcuYm6uJTcUAERz_KBeYFNpbTaj3cAxdSlSFNKew0&usqp=CAU"  />
</div>

###

<p align="left">Manajemen Stok:</p>

###

<div align="center">
  <img height="200" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgQZab-d6tnN4D1g_iHkzEvh75XF8Q7Y0xV1IXF5zU-PnuuDECAMpOcyCvAy80CXlZQfg&usqp=CAU"  />
</div>

###

<p align="left">Frontend:</p>

###

<div align="center">
  <img height="200" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRksDezkA7S80qfdJT1Ef5DwpEompUcuYm6uJTcUAERz_KBeYFNpbTaj3cAxdSlSFNKew0&usqp=CAU"  />
</div>

###