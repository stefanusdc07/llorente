<x-filament-widgets::widget>
    <x-filament::section>
        <x-filament::table>
        </x-filament::table>
    </x-filament::section>
</x-filament-widgets::widget>
