<x-filament-panels::page>
    <div>
        @livewire(\App\Livewire\Sales::class)
    </div>
</x-filament-panels::page>
