<button
    type="button"
    aria-label="Support"
    class="<?php echo e(config('support-bubble.classes.bubble')); ?>"
>
    <?php echo $__env->make('support-bubble::includes.chat-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</button>
<?php /**PATH C:\laragon\www\qoqet\vendor\spatie\laravel-support-bubble\src\/../resources/views/includes/bubble.blade.php ENDPATH**/ ?>