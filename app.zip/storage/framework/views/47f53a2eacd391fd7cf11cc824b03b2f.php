<div class="spatie-support-bubble | pointer-events-none fixed bottom-0 <?php echo e($direction === 'right-to-left' ? 'left-0' : 'right-0'); ?> <?php echo e(config('support-bubble.classes.container')); ?>"
     style="max-width: 340px; display: none;">
    <div class="spatie-support-bubble__container | pointer-events-none bg-white shadow-xl border border-gray-300 rounded p-6 transition transform <?php echo e($direction === 'right-to-left' ? '-translate-x-full' : 'translate-x-full'); ?> opacity-0">
        <div class="spatie-support-bubble__form pointer-events-auto">
            <?php echo $__env->make('support-bubble::includes.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="spatie-support-bubble__response" style="display: none">
        </div>
    </div>

    <div class="spatie-support-bubble__button | pointer-events-auto">
        <?php echo $__env->make('support-bubble::includes.bubble', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php if (! $__env->hasRenderedOnce('64fa30ed-5076-4373-90c9-d21c42d69ee9')): $__env->markAsRenderedOnce('64fa30ed-5076-4373-90c9-d21c42d69ee9'); ?>
    <?php echo $__env->make('support-bubble::includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\qoqet\vendor\spatie\laravel-support-bubble\src\/../resources/views/components/support-bubble.blade.php ENDPATH**/ ?>