<?php
    $brandName = filament()->getBrandName();
    $brandLogo = filament()->getBrandLogo()
?>

<?php if(filled($brandLogo)): ?>
    <img
        src="<?php echo e($brandLogo); ?>"
        loading="lazy"
        alt="<?php echo e($brandName); ?>"
        <?php echo e($attributes->class(['fi-logo h-10'])); ?>

    />
<?php else: ?>
    <div
        <?php echo e($attributes->class(['fi-logo text-xl font-bold leading-5 tracking-tight text-gray-950 dark:text-white'])); ?>

    >
        <?php echo e($brandName); ?>

    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\qoqet\vendor\filament\filament\src\/../resources/views/components/logo.blade.php ENDPATH**/ ?>