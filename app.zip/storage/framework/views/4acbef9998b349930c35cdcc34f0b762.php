<?php $__env->startSection('title', __('Not found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('The server did not find the requested address')); ?>

<?php $__env->startSection('link'); ?>
    <a href="<?php echo e(url('/')); ?>" class="btn btn-link"><?php echo e(__('Back to homepage')); ?></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\qoqet\resources\views/errors/404.blade.php ENDPATH**/ ?>