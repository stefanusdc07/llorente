<?php

declare(strict_types=1);

return [
    'organization_slug' => env('SENTRY_ORG_SLUG'),
    'project_slug' => env('SENTRY_PROJECT_SLUG'),
];
