<?php

return [
    'admin_hash_password' => env('SUPER_ADMIN_PASSWORD_HASH'),
];
