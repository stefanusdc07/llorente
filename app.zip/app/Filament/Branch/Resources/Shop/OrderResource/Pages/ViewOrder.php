<?php

declare(strict_types=1);

namespace App\Filament\Branch\Resources\Shop\OrderResource\Pages;

use App\Filament\Branch\Resources\Shop\OrderResource;

class ViewOrder extends \App\Filament\Resources\Shop\OrderResource\Pages\ViewOrder
{
    protected static string $resource = OrderResource::class;
}
