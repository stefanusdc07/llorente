<?php

declare(strict_types=1);

namespace App\Filament\Branch\Resources\Shop\SkuStockResource\Pages;

use App\Filament\Branch\Resources\Shop\SkuStockResource;

class CreateSkuStock extends \App\Filament\Resources\Shop\SkuStockResource\Pages\CreateSkuStock
{
    protected static string $resource = SkuStockResource::class;
}
