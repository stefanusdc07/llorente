<?php

declare(strict_types=1);

return [
    'super_admin' => 'super_admin',
    'admin' => 'admin',
    'branch' => 'branch',
];
